This directory is deprecated. All validation models have been migrated to app/schemas.py. You may safely remove all files in this directory.
